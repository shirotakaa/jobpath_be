<?php $__env->startSection('content'); ?>

        <!-- Content -->
        <main class="main">
            <section class="section-box">
                <div class="banner-hero hero-1">
                    <div class="banner-inner">
                        <div class="row">
                            <div class="col-lg-8">
                                <div class="block-banner">
                                    <span class="text-small-primary text-small-primary--disk text-uppercase wow animate__animated animate__fadeInUp">JobPath</span>
                                    <h1 class="heading-banner wow animate__animated animate__fadeInUp"><?php echo e($hero->judul_hero); ?></h1>
                                    <div class="banner-description mt-30 wow animate__animated animate__fadeInUp" data-wow-delay=".1s">
                                        <?php echo e($hero->subtitle_hero); ?>

                                    </div>
                                    <div class="form-find mt-60 wow animate__animated animate__fadeInUp" data-wow-delay=".2s">
                                        <form method="GET" action="<?php echo e(route('daftar-pekerjaan')); ?>">
                                            <input type="text" name="query" class="form-input input-keysearch mr-10"
                                                placeholder="Job title, Company..." />
                                            <select name="kategori" class="form-input mr-10 select-active">
                                                <option value="">Pilih Kategori</option>
                                                <option value="Design">Design</option>
                                                <option value="Marketing">Marketing</option>
                                                <option value="Technology">Technology</option>
                                                <option value="Engineering">Engineering</option>
                                                <option value="Finance">Finance</option>
                                            </select>
                                            <button type="submit" class="btn btn-default btn-find">Temukan</button>
                                        </form>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="banner-imgs">
                                    <div class="box-image-findjob findjob-homepage-2 wow animate__animated animate__fadeIn"
                                        style="z-index: -1; margin-left: -30px;">
                                        <figure style="width: 437px; height: 513px;">
                                            <img class="img-responsive shape-1" alt="JobPath"
                                                src="<?php echo e($hero->background_image ? asset('storage/' . $hero->background_image) : asset('assets/admin/media/svg/blank-image.svg')); ?>"
                                                style="width: 100%; height: 100%; object-fit: cover;" />
                                        </figure>                                    
                                    </div>
                                    <span class="union-icon"><img alt="JobPath" src="assets/user/imgs/banner/union.svg"
                                            class="img-responsive shape-3" /></span>
                                    <span class="congratulation-icon"><img alt="JobPath"
                                            src="assets/user/imgs/banner/congratulation.svg"
                                            class="img-responsive shape-2" /></span>
                                    <span class="docs-icon"><img alt="JobPath" src="assets/user/imgs/banner/docs.svg"
                                            class="img-responsive shape-2" /></span>
                                    <span class="course-icon"><img alt="JobPath" src="assets/user/imgs/banner/course.svg"
                                            class="img-responsive shape-3" /></span>
                                    <span class="web-dev-icon"><img alt="JobPath" src="assets/user/imgs/banner/web-dev.svg"
                                            class="img-responsive shape-3" /></span>
                                    <span class="tick-icon"><img alt="JobPath" src="assets/user/imgs/banner/tick.svg"
                                            class="img-responsive shape-3" /></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="section-box mt-70">
                <div class="container">
                    <div class="row align-items-end">
                        <div class="col-lg-7">
                            <h2 class="section-title mb-20 wow animate__animated animate__fadeInUp">Mitra Perusahaan</h2>
                            <p class="text-md-lh28 color-black-5 wow animate__animated animate__fadeInUp">Daftar perusahaan
                                yang telah bekerja sama dan membuka peluang bagi para alumni.</p>
                        </div>
                        
                    </div>
                    <div class="row mt-70">
                        <?php $__currentLoopData = $perusahaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-6">
                                <div class="card-grid-2 card-employers hover-up wow animate__animated animate__fadeIn">
                                    <div class="text-center card-grid-2-image-rd">
                                        <a href="#">
                                            <figure style=" width: 110px ;height: 110px;">
                                                <img alt="JobPath"
                                                    src="<?php echo e($item->logo ? asset($item->logo) : 'assets/user/imgs/employers/employer-default.png'); ?>"
                                                    class="w-100 h-100 object-fit-cover" />
                                            </figure>
                                        </a>
                                    </div>
                                    <div class="card-block-info">
                                        <div class="card-profile">
                                            <h5><a href="#"><strong><?php echo e($item->nama_perusahaan); ?></strong></a></h5>
                                            <span class="text-sm"><?php echo e($item->lokasi); ?></span>
                                        </div>
                                        <div class="mt-15 d-flex flex-column align-items-center text-center">
                                        </div>
                                        <div class="card-2-bottom card-2-bottom-candidate">
                                            <div class="text-center mb-5">
                                                <a href="#" class="btn btn-border btn-brand-hover"
                                                    data-bs-toggle="modal" data-bs-target="#loginModal">
                                                    <?php echo e($item->jumlah_lowongan); ?> Open
                                                    Jobs
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
            </section>
            <section class="section-box mt-40">
                <div class="container">
                    <div class="row align-items-end">
                        <div class="col-lg-7">
                            <h2 class="section-title mb-20 wow animate__animated animate__fadeInUp">Kategori Lowongan</h2>
                            <p class="text-md-lh28 color-black-5 wow animate__animated animate__fadeInUp">
                                Pilih Kategori Pekerjaan yang Sesuai dengan Keahlian dan Minat Anda
                            </p>
                        </div>
                        <div class="col-lg-5 text-lg-end text-start wow animate__animated animate__fadeInUp" data-wow-delay=".2s">
                            <a href="job-grid.html" class="mt-sm-15 mt-lg-30 btn btn-border icon-chevron-right">Lihat Semua</a>
                        </div>
                    </div>
                    <div class="row mt-70">
                        <?php $__currentLoopData = $kategoriPekerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-6 col-sm-12 col-12">
                                <div class="card-grid hover-up wow animate__animated animate__fadeInUp" 
                                     data-wow-delay=".<?php echo e($loop->index * 1); ?>s" 
                                     onclick="searchByCategory('<?php echo e($kategori['nama']); ?>')" 
                                     style="cursor: pointer;">
                                    <div class="text-center">
                                        <a class="d-inline-block">
                                            <figure class="rounded-circle overflow-hidden d-flex align-items-center justify-content-center m-0" style="width: 85px; height: 85px;">
                                                <?php
                                                    $iconName = strtolower(str_replace(' ', '-', $kategori['nama']));
                                                ?>
                                                <img src="assets/user/imgs/icons/<?php echo e($iconName); ?>.svg" alt="<?php echo e($kategori['nama']); ?>" class="w-100 h-100 object-fit-cover"/>
                                            </figure>
                                        </a>
                                    </div>
                                    <h5 class="text-center mt-20">
                                        <a class="text-dark"><?php echo e($kategori['nama']); ?></a>
                                    </h5>
                                    <p class="text-center text-stroke-40 mt-20"><?php echo e($kategori['jumlah']); ?> Lowongan Tersedia</p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-6 col-sm-12 col-12">
                            <div class="card-grid hover-up wow animate__animated animate__fadeInUp" data-wow-delay=".3s">
                                <div class="text-center mt-15">
                                    <h3><?php echo e($kategoriPekerjaan->sum('jumlah')); ?>+</h3>
                                </div>
                                <p class="text-center mt-30 text-stroke-40">Pekerjaan menunggu Anda</p>
                                <div class="text-center mt-30">
                                    <div class="box-button-shadow">
                                        <a href="<?php echo e(route('daftar-pekerjaan')); ?>" class="btn btn-default">Jelajahi lebih lanjut</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="section-box mt-40">
                <div class="container">
                    <div class="row align-items-end">
                        <div class="col-lg-4">
                            <h2 class="section-title mb-20">Lowongan Pekerjaan</h2>
                            <p class="text-md-lh28 color-black-5">Cari peluang kerja sesuai keahlian.</p>
                        </div>
                        <div class="col-lg-8 text-xl-end text-start">
                            <ul class="nav nav-right float-xl-end float-start" role="tablist">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <button id="nav-tab-<?php echo e($index); ?>" data-bs-toggle="tab"
                                            data-bs-target="#tab-<?php echo e($index); ?>" type="button" role="tab"
                                            aria-controls="tab-<?php echo e($index); ?>" aria-selected="<?php echo e($index == 0 ? 'true' : 'false'); ?>"
                                            class="<?php echo e($index == 0 ? 'active' : ''); ?>">
                                            <?php echo e(ucfirst($category)); ?>

                                        </button>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                
                    <div class="mt-70">
                        <div class="tab-content" id="myTabContent">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tab-pane fade <?php echo e($index == 0 ? 'show active' : ''); ?>" id="tab-<?php echo e($index); ?>"
                                     role="tabpanel" aria-labelledby="tab-<?php echo e($index); ?>">
                                    <div class="row">
                                        <?php
                                            $jobs = \App\Models\Pekerjaan::where('kategori', $category)->get();
                                        ?>
                                        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-lg-4 col-md-6">
                                                <div class="card-grid-2 hover-up">
                                                    <div class="card-block-info">
                                                        <div class="row">
                                                            <div class="col-lg-12 col-12"
                                                                 style="display: flex; justify-content: space-between; gap: 16px;">
                                                                <a href="<?php echo e(route('daftar-pekerjaan', $job->id_pekerjaan)); ?>"
                                                                   class="card-2-img-text card-grid-2-img-medium">
                                                                    <span class="card-grid-2-img-small">
                                                                        <img alt="Job Image" src="assets/user/imgs/job/ui-ux.svg"
                                                                             class="w-100 h-100 object-fit-cover"/>
                                                                    </span>
                                                                    <span><?php echo e($job->judul_pekerjaan); ?></span>
                                                                </a>
                                                                <div class="text-end pt-5">
                                                                    <span class="text-gray-100 text-md"><i class="fi-rr-bookmark"></i></span>
                                                                </div>
                                                            </div>
                                                        </div>
                
                                                        <div class="mt-15" style="display: flex; gap: 24px;">
                                                            <a href="#">
                                                                <span class="text-brand-10 text-icon-first"><?php echo e($job->perusahaan->nama_perusahaan); ?></span>
                                                            </a>
                                                            <span class="text-mutted-2" style="font-size: 12px;">
                                                                <i class="fi-rr-marker" style="font-size: 12px;"></i> <?php echo e($job->lokasi); ?>

                                                            </span>
                                                        </div>
                
                                                        <div class="text-small mt-15">
                                                            <?php echo e(Str::limit($job->about_job, 100)); ?>

                                                        </div>
                
                                                        <div class="card-2-bottom mt-30">
                                                            <div class="row">
                                                                <div class="col-lg-6 col-4">
                                                                    <span class="card-text-price"> <?php echo e($job->rentang_gaji); ?> </span>
                                                                </div>
                                                                <div class="col-lg-6 col-8 text-end">
                                                                    <a href="<?php echo e(route('daftar-pekerjaan', $job->id_pekerjaan)); ?>">
                                                                        <span class="text-brand-10">Lamar Sekarang</span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>                
            </section>
            <section class="section-box mt-40">
                <div class="container">
                    <div class="row align-items-end">
                        <div class="col-lg-7">
                            <h2 class="section-title mb-20 wow animate__animated animate__fadeInUp">Jejak Alumni</h2>
                            <p class="text-md-lh28 color-black-5 wow animate__animated animate__fadeInUp">Mengikuti
                                Perjalanan dan Kesuksesan Alumni di Dunia Kerja</p>
                        </div>
                        <div class="col-lg-5 text-lg-end text-start wow animate__animated animate__fadeInUp"
                            data-wow-delay=".2s">
                            <a href="<?php echo e(route('jejak-alumni')); ?>"
                                class="mt-sm-15 mt-lg-30 btn btn-border icon-chevron-right">Lihat
                                Semua</a>
                        </div>
                    </div>
                    <div class="row mt-70">
                        <?php $__currentLoopData = $alumni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4 col-md-6">
                                <div class="card-grid-2 hover-up">
                                    <div class="text-center card-grid-2-image-rd">
                                        <a href="#">
                                            <figure style="width: 110px; height: 110px;">
                                                <img alt="<?php echo e($item->nama); ?>" src="<?php echo e(asset('storage/' . $item->foto)); ?>" class="w-100 h-100 object-fit-cover" />
                                            </figure>
                                        </a>
                                    </div>
                                    <div class="card-block-info">
                                        <div class="card-profile">
                                            <a href="#"><strong><?php echo e($item->nama); ?></strong></a>
                                            <span class="text-sm" style="color: #1f2938;">
                                                Sebagai alumni SMKN 4 Malang jurusan <?php echo e($item->jurusan); ?>, saya bekerja sebagai <?php echo e($item->pekerjaan); ?> di <?php echo e($item->perusahaan); ?>.
                                            </span>
                                        </div>
                                        <div class="employers-info d-flex align-items-center justify-content-center mt-15">
                                            <span class="d-flex align-items-center"><i class="fi-rr-briefcase mr-5 ml-0" style="font-size: 16px;"></i><?php echo e($item->pekerjaan); ?></span>
                                            <span class="d-flex align-items-center ml-25"><i class="fi-rr-briefcase mr-5" style="font-size: 16px;"></i><?php echo e($item->perusahaan); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>                
                </div>
            </section>
        </main>
        <!-- End Content -->
        <script>
            function searchByCategory(category) {
                // Redirect ke halaman daftar-pekerjaan dengan parameter kategori
                window.location.href = `/daftar-pekerjaan?query=${encodeURIComponent(category)}`;
            }
        
            function selectCategory(category) {
                // Set nilai input pencarian
                document.getElementById('jobSearchInput').value = category;
            }
        </script>        
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\jobpath_be\resources\views/user/index.blade.php ENDPATH**/ ?>