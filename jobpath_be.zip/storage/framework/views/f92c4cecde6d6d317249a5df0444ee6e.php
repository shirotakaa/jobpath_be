<?php $__env->startSection('content'); ?>


    <!-- Content -->
    <main class="main">
        <section class="section-box">
            <div class="container pt-50">
                <div class="w-50 w-md-100 mx-auto text-center">
                    <h1 class="section-title-large mb-30 wow animate__animated animate__fadeInUp">FAQs</h1>
                    <p class="mb-30 text-muted wow animate__animated animate__fadeInUp font-md">
                        <?php echo e($faqContent->deskripsi ?? 'Cek pertanyaan yang sering diajukan di sini sebelum menghubungi kami. Berikut beberapa masalah umum yang mungkin Anda temui saat menggunakan sistem kami.'); ?>

                    </p>
                </div>
            </div>
        </section>
        <div class="faqs-imgs">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 mx-auto">
                        <div class="row">
                            <div class="col-lg-7">
                                <img class="faqs-1 wow animate__animated animate__fadeIn" data-wow-delay=".1s"
                                    src="<?php echo e(asset($faqContent) && $faqContent->asset_1 ? asset('storage/' . $faqContent->asset_1) : asset('assets/admin/media/svg/blank.svg')); ?>" alt="FAQ Image 1">
                            </div>
                            <div class="col-lg-5">
                                <img class="faqs-2 mb-15 wow animate__animated animate__fadeIn" data-wow-delay=".3s"
                                    src="<?php echo e(asset($faqContent) && $faqContent->asset_2 ? asset('storage/' . $faqContent->asset_2) : asset('assets/admin/media/svg/blank.svg')); ?>" alt="FAQ Image 2">
                                <img class="faqs-3 wow animate__animated animate__fadeIn" data-wow-delay=".5s"
                                    src="<?php echo e(asset($faqContent) && $faqContent->asset_3 ? asset('storage/' . $faqContent->asset_3) : asset('assets/admin/media/svg/blank.svg')); ?>" alt="FAQ Image 3">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <section class="mt-80">
            <div class="container">
                <div class="row align-items-end mb-50">
                    <div class="col-lg-5">
                        <span class="text-blue wow animate__animated animate__fadeInUp">Questions</span>
                        <h3 class="mt-20 wow animate__animated animate__fadeInUp">Frequently Asked Questions</h3>
                    </div>
                    <div class="col-lg-2"></div>
                    <div class="col-lg-5">
                        <p class="text-lg text-muted wow animate__animated animate__fadeInUp">
                            Temukan jawaban atas pertanyaan yang sering diajukan mengenai layanan kami.
                        </p>
                    </div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $faqs->chunk(ceil($faqs->count() / 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faqChunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6">
                            <div class="accordion accordion-flush" id="accordionFlushExample<?php echo e($loop->index); ?>">
                                <?php $__currentLoopData = $faqChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="heading<?php echo e($loop->parent->index); ?><?php echo e($loop->index); ?>">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                                data-bs-target="#collapse<?php echo e($loop->parent->index); ?><?php echo e($loop->index); ?>"
                                                aria-expanded="false"
                                                aria-controls="collapse<?php echo e($loop->parent->index); ?><?php echo e($loop->index); ?>">
                                                <?php echo e($faq->pertanyaan); ?>

                                            </button>
                                        </h2>
                                        <div id="collapse<?php echo e($loop->parent->index); ?><?php echo e($loop->index); ?>"
                                            class="accordion-collapse collapse"
                                            aria-labelledby="heading<?php echo e($loop->parent->index); ?><?php echo e($loop->index); ?>"
                                            data-bs-parent="#accordionFlushExample<?php echo e($loop->parent->index); ?>">
                                            <div class="accordion-body">
                                                <p class="mb-15"><?php echo e($faq->jawaban); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    </main>
    <!-- End Content -->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\jobpath_be\resources\views/user/faq-user.blade.php ENDPATH**/ ?>