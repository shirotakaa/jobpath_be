

<div class="row job-listing-grid-2" style="padding-top: 8px;">
    <?php $__currentLoopData = $alumni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6 alumni-card">
            <div class="card-grid-2 hover-up">
                <div class="text-center card-grid-2-image-rd">
                    <a href="#">
                        <figure style="width: 110px; height: 110px;">
                            <img alt="<?php echo e($item->nama); ?>" src="<?php echo e(asset('storage/' . $item->foto)); ?>" class="w-100 h-100 object-fit-cover" />
                        </figure>
                    </a>
                </div>
                <div class="card-block-info">
                    <div class="card-profile">
                        <a href="#"><strong><?php echo e($item->nama); ?></strong></a>
                        <span class="text-sm" style="color: #1f2938;">
                            Sebagai alumni SMKN 4 Malang dengan jurusan <?php echo e($item->jurusan); ?>.
                            Sekarang saya bekerja sebagai <?php echo e($item->pekerjaan); ?> di <?php echo e($item->perusahaan); ?>.
                        </span>
                    </div>
                    <div class="employers-info d-flex align-items-center justify-content-center mt-15">
                        <span class="d-flex align-items-center">
                            <i class="fi-rr-briefcase mr-5 ml-0" style="font-size: 16px;"></i><?php echo e($item->pekerjaan); ?>

                        </span>
                        <span class="d-flex align-items-center ml-25">
                            <i class="fi-rr-briefcase mr-5" style="font-size: 16px;"></i><?php echo e($item->perusahaan); ?>

                        </span>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<?php if($alumni->lastPage() > 1): ?>
    <div class="paginations text-center mt-4">
        <ul class="pager d-inline-flex justify-content-center list-unstyled">
            <?php if($alumni->onFirstPage()): ?>
                <li><span class="pager-prev disabled">←</span></li>
            <?php else: ?>
                <li><a href="<?php echo e($alumni->previousPageUrl()); ?>" class="pager-prev">←</a></li>
            <?php endif; ?>

            <?php for($i = 1; $i <= $alumni->lastPage(); $i++): ?>
                <li>
                    <a href="<?php echo e($alumni->url($i)); ?>" class="pager-number <?php echo e($alumni->currentPage() == $i ? 'active' : ''); ?>"><?php echo e($i); ?></a>
                </li>
            <?php endfor; ?>

            <?php if($alumni->hasMorePages()): ?>
                <li><a href="<?php echo e($alumni->nextPageUrl()); ?>" class="pager-next">→</a></li>
            <?php else: ?>
                <li><span class="pager-next disabled">→</span></li>
            <?php endif; ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\jobpath_be\resources\views/user/layout/_alumni-cards.blade.php ENDPATH**/ ?>